import React from 'react';
import './App.css';
import {ButtonPanelComponent} from "./ButtonPanelComponent/ButtonPanelComponent";
import {DisplayComponent} from "./DisplayComponent/DisplayComponent";

export class App extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
        this.state = {
            value: 0,
            oldValues: 0,
            operator: ''
        }
        this.linkParent = this.linkParent.bind(this);
    }

    render() {
        return(
            <div id="container">
                <div id="calculator">
                    <DisplayComponent value={this.state.value} oldValues={this.state.oldValues} operator={this.state.operator}/>
                    <ButtonPanelComponent parentCallback={this.linkParent}/>
                </div>
            </div>
        )
    }

    linkParent(value: number) {
        this.setState({value: value})
    }
}

export default App;
