import React from "react";
import './ButtonPanelComponent.css'
import {Operation} from "../models/Operation";

export class ButtonPanelComponent extends React.Component<any, any> {

    constructor(props: { parentCallback: (arg0: number) => void; }) {

    super(props);
    this.state = {
        value: 0,
        oldValues: 0,
        operator: '',
        isResult: false
    }
  }

  render() {
    return (
        <div id="buttons">
            <div id="row">
                <div id="button" onClick={()=>this.whenClicked(1)}><p>1</p></div>
                <div id="button" onClick={()=>this.whenClicked(2)}><p>2</p></div>
                <div id="button" onClick={()=>this.whenClicked(3)}><p>3</p></div>
                <div id="button" className="no-border" onClick={()=>this.clear()}><p>C</p></div>
            </div>
            <div id="row">
                <div id="button" onClick={()=>this.whenClicked(4)}><p>4</p></div>
                <div id="button" onClick={()=>this.whenClicked(5)}><p>5</p></div>
                <div id="button" onClick={()=>this.whenClicked(6)}><p>6</p></div>
                <div id="button" className="no-border" onClick={()=>this.subtraction()}><p>-</p></div>
            </div>
            <div id="row">
                <div id="button" onClick={()=>this.whenClicked(7)}><p>7</p></div>
                <div id="button" onClick={()=>this.whenClicked(8)}><p>8</p></div>
                <div id="button" onClick={()=>this.whenClicked(9)}><p>9</p></div>
                <div id="button" className="no-border" onClick={()=>this.addition()}><p>+</p></div>
            </div>
            <div id="row">
                <div id="button" className="double" onClick={()=>this.whenClicked(0)}><p>0</p></div>
                <div id="button" onClick={()=>this.multiplication()}><p>x</p></div>
                <div id="button" className="no-border" onClick={()=>this.equals()}><p>=</p></div>
            </div>
        </div>
    );
  }

  whenClicked(number: number) {
      console.log(this.state.isResult)
    if (this.state.value == 0) {
        this.setState({value: number});
        setTimeout(() => {
            this.props.parentCallback(this.state.value);

        }, 100);

    }
    else {
        if (this.state.isResult) {
            console.log('here')
            this.setState({value: number});
            this.setState({isResult: false});
            console.log(number)
            this.props.parentCallback(number);
        }
        else {
            this.setState({value: '' + this.state.value + number});
            setTimeout(() => {
                console.log(this.state.value)
                this.props.parentCallback(this.state.value);
            }, 100);
        }
    }
  }

  addition() {
    this.setState({oldValues: this.state.value});
    this.setState({value: 0});
    this.setState({operator: Operation.Add});
  }

  subtraction() {
      this.setState({oldValues: this.state.value});
      this.setState({value: 0});
      this.setState({operator: Operation.Subtract});
  }

  multiplication() {
      this.setState({oldValues: this.state.value});
      this.setState({value: 0});
      this.setState({operator: Operation.Multiply});
  }


  equals() {
      this.setState({isResult: true});
      if (this.state.operator == '+') {
        this.setState({value: parseInt(this.state.oldValues) + parseInt(this.state.value)});
        console.log(this.state.value)

    }
    else if (this.state.operator == '-') {
        this.setState({value: parseInt(this.state.oldValues) - parseInt(this.state.value)});
        console.log(this.state.value)

    }
    else if (this.state.operator == '*') {
        this.setState({value: parseInt(this.state.oldValues) * parseInt(this.state.value)});
    }
    setTimeout(() => {
        this.props.parentCallback(this.state.value);
    }, 100);
  }

  clear() {
    this.setState({value: 0});
    this.setState({oldValues: 0});
    this.setState({operator: ''});
    this.props.parentCallback(0);
  }

}
