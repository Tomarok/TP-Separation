export enum Operation {
    Add = '+',
    Subtract = '-',
    Multiply = '*',
}