import React from "react";

export class DisplayComponent extends React.Component<any, any> {

    constructor(props: any) {
    super(props);

  }

  render() {
      const {value} = this.props;
      return (
        <div id="screen">
            <div className="circle" id="close"></div>
            <div className="circle" id="max"></div>
            <div className="circle" id="min"></div>
            <div id="formula"></div>
            <div id="result">{value}</div>

        </div>
    );
  }
}