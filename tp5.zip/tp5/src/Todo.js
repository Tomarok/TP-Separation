import React from "react";
import './Todo.css';

export class Todo extends React.Component {
    state = {
        todos: []
    };

    constructor(props) {
        super(props);
        const { todos } = props;
        this.state.todos = todos;
    }

    render() {
        return (
            <ul>
                {
                    this.state.todos.map((todoItem, index) => {
                        return (
                            <li key={ index }>
                                <p className={ todoItem.completed ? 'completed' : '' }>{ todoItem.title }</p>
                            </li>
                        );
                    })
                }
            </ul>

        )
    }
}
